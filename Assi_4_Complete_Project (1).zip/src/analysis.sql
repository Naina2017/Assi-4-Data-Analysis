-- Week 4 Data Analyst Capstone - SQL Analysis

-- 1. Overall KPIs
SELECT
    SUM(sales) AS total_sales,
    SUM(profit) AS total_profit,
    SUM(units_sold) AS total_units_sold,
    ROUND(SUM(profit) * 100.0 / NULLIF(SUM(sales),0), 2) AS profit_margin_pct
FROM sales_data;

-- 2. Sales and profit by segment
SELECT segment,
       SUM(sales) AS sales,
       SUM(profit) AS profit,
       ROUND(SUM(profit) * 100.0 / NULLIF(SUM(sales),0), 2) AS profit_margin_pct
FROM sales_data
GROUP BY segment
ORDER BY sales DESC;

-- 3. Product performance
SELECT product,
       SUM(sales) AS sales,
       SUM(profit) AS profit,
       SUM(units_sold) AS units_sold
FROM sales_data
GROUP BY product
ORDER BY sales DESC;

-- 4. Country performance
SELECT country,
       SUM(sales) AS sales,
       SUM(profit) AS profit
FROM sales_data
GROUP BY country
ORDER BY profit DESC;

-- 5. Monthly trend
SELECT date,
       SUM(sales) AS sales,
       SUM(profit) AS profit
FROM sales_data
GROUP BY date
ORDER BY date;

-- 6. Discount-band analysis
SELECT discount_band,
       SUM(discounts) AS discounts,
       SUM(sales) AS sales,
       SUM(profit) AS profit,
       ROUND(SUM(profit) * 100.0 / NULLIF(SUM(sales),0), 2) AS profit_margin_pct
FROM sales_data
GROUP BY discount_band
ORDER BY profit_margin_pct DESC;
