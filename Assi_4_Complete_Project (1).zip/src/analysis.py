import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

DATA_PATH = "data/cleaned_sales_data.csv"

df = pd.read_csv(DATA_PATH, parse_dates=["date"])
df["profit_margin_pct"] = np.where(
    df["sales"] != 0, df["profit"] / df["sales"] * 100, 0
)

print("Dataset shape:", df.shape)
print("\nMissing values:\n", df.isna().sum())
print("\nBasic statistics:\n", df[["units_sold","sales","cogs","profit"]].describe())

print("\nOverall KPIs")
print("Sales:", round(df["sales"].sum(), 2))
print("Profit:", round(df["profit"].sum(), 2))
print("Units:", round(df["units_sold"].sum(), 2))
print("Profit margin:", round(df["profit"].sum()/df["sales"].sum()*100, 2), "%")

segment = df.groupby("segment").agg(
    Sales=("sales","sum"), Profit=("profit","sum"), Units=("units_sold","sum")
).sort_values("Sales", ascending=False)
print("\nSales by segment:\n", segment)

product = df.groupby("product").agg(
    Sales=("sales","sum"), Profit=("profit","sum"), Units=("units_sold","sum")
).sort_values("Sales", ascending=False)
print("\nProduct performance:\n", product)

country = df.groupby("country").agg(
    Sales=("sales","sum"), Profit=("profit","sum"), Units=("units_sold","sum")
).sort_values("Profit", ascending=False)
print("\nCountry performance:\n", country)

monthly = df.groupby("date").agg(
    Sales=("sales","sum"), Profit=("profit","sum")
).sort_index()
monthly.plot(y="Sales", marker="o", title="Monthly Sales Trend")
plt.tight_layout()
plt.show()
