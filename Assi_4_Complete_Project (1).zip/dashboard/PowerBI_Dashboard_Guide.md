# Power BI Dashboard Guide

## Data
Load `data/cleaned_sales_data.csv` into Power BI.

## Suggested KPI cards
- Total Sales = SUM(cleaned_sales_data[sales])
- Total Profit = SUM(cleaned_sales_data[profit])
- Units Sold = SUM(cleaned_sales_data[units_sold])
- Profit Margin % = DIVIDE([Total Profit], [Total Sales], 0)

## Suggested visuals
1. Line chart: Date vs Total Sales
2. Clustered bar: Segment vs Total Sales
3. Bar chart: Product vs Total Profit
4. Bar chart: Country vs Total Profit
5. Donut: Discount Band vs Sales
6. Slicers: Year, Country, Segment, Product, Discount Band

## DAX measures

Total Sales = SUM('cleaned_sales_data'[sales])

Total Profit = SUM('cleaned_sales_data'[profit])

Units Sold = SUM('cleaned_sales_data'[units_sold])

Total Discounts = SUM('cleaned_sales_data'[discounts])

Profit Margin % = DIVIDE([Total Profit], [Total Sales], 0)

## Dashboard story
Start with the KPI cards, then show the monthly sales trend, segment contribution, product profitability and country performance. Use slicers to let a stakeholder explore a specific year, country or segment.
