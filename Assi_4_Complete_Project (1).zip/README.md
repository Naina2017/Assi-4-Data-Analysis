# Week 4 Data Analyst Capstone Project

## Project: Sales Performance Analysis & Dashboard

This project analyzes a sales dataset containing 700 records across products, countries, customer segments, discounts and dates.

### Tools
- Python (Pandas, NumPy, Matplotlib)
- SQL
- Power BI-ready data and dashboard guide
- Excel dashboard
- Interactive Plotly HTML dashboard

### Project workflow
1. Load and inspect the raw dataset.
2. Clean column names and missing discount-band values.
3. Create calculated profit margin.
4. Explore sales, profit, units, discounts and COGS.
5. Analyze performance by segment, product and country.
6. Analyze monthly sales trends.
7. Prepare dashboard-ready summaries.
8. Write business findings and recommendations.

### Key findings
- Total sales: approximately ₹118.73M.
- Total profit: approximately ₹16.89M.
- Overall profit margin: approximately 14.23%.
- Government is the largest segment by sales.
- Enterprise is the only segment with negative total profit in this dataset.
- Paseo is the highest-sales product.
- France has the highest total profit among the five countries.
- High discount-band sales have a lower profit margin than low discount-band sales.

### Files
- `data/cleaned_sales_data.csv` - cleaned dataset
- `src/analysis.py` - Python analysis
- `src/analysis.sql` - SQL queries
- `dashboard/dashboard.html` - interactive dashboard
- `dashboard/PowerBI_Dashboard_Guide.md` - Power BI build guide and DAX
- `excel/Week4_Sales_Dashboard.xlsx` - Excel dashboard and summary tables
- `reports/Week4_Data_Analysis_Report.pdf` - final explanation report
- `charts/` - supporting charts

## How to run
```bash
pip install -r requirements.txt
python src/analysis.py
```

Open `dashboard/dashboard.html` in a browser to view the interactive dashboard.
